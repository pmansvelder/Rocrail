/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Feb  1 2015 10:28:17)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Feb  1 10:28:29 2015
  */

#include "rocs/public/attr.h"


static const char* name = "OAttr";

typedef struct OAttrData {

    /** Attribute name. */
  char* name;
    /** Attribute value. */
  char* val;
    /** Attribute value.(Un-escaped.) */
  char* origval;
    /** Attribute is escaped. */
  Boolean escaped;

} *iOAttrData;

static iOAttrData Data( void* p ) { return (iOAttrData)((iOAttr)p)->base.data; }

