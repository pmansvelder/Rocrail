/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jun  6 2015 14:55:49)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Jun  7 08:59:25 2015
  */

#include "rocs/public/gzip.h"


static const char* name = "OGZip";

typedef struct OGZipData {

    /**  */
  char* name;
    /**  */
  int rc;

} *iOGZipData;

static iOGZipData Data( void* p ) { return (iOGZipData)((iOGZip)p)->base.data; }

