/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Apr 19 2015 09:26:30)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Apr 19 09:58:03 2015
  */

#include "rocs/public/cmdln.h"


static const char* name = "OCmdLn";

typedef struct OCmdLnData {

    /** Argument count. */
  int argc;
    /** Argument values. */
  const char** argv;
    /** Argument values mapped with their key. */
  iOMap argMap;
    /**  */
  char* argStr;

} *iOCmdLnData;

static iOCmdLnData Data( void* p ) { return (iOCmdLnData)((iOCmdLn)p)->base.data; }

