/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jun  6 2015 14:55:49)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Jun  7 08:59:25 2015
  */

#include "rocs/public/system.h"

/* rocs and system includes: */
#include "rocs/public/thread.h"

static const char* name = "OSystem";

typedef struct OSystemData {

    /**  */
  char WSName[64];
    /**  */
  char UserName[64];
    /**  */
  iOThread ticker;
    /**  */
  unsigned long tick;

} *iOSystemData;

static iOSystemData Data( void* p ) { return (iOSystemData)((iOSystem)p)->base.data; }

