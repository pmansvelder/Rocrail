/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jul 29 2015 10:10:26)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Jul 29 10:10:35 2015
  */

#include "rocs/public/system.h"

/* rocs and system includes: */
#include "rocs/public/thread.h"

static const char* name = "OSystem";

typedef struct OSystemData {

    /**  */
  char WSName[64];
    /**  */
  char UserName[64];
    /**  */
  iOThread ticker;
    /**  */
  unsigned long tick;

} *iOSystemData;

static iOSystemData Data( void* p ) { return (iOSystemData)((iOSystem)p)->base.data; }

