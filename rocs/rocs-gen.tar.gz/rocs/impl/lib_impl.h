/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Feb  1 2015 10:28:17)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Feb  1 10:28:29 2015
  */

#include "rocs/public/lib.h"


static const char* name = "OLib";

typedef struct OLibData {

    /** Library name. */
  char* name;
    /** Library handle. */
  void* lh;

} *iOLibData;

static iOLibData Data( void* p ) { return (iOLibData)((iOLib)p)->base.data; }

