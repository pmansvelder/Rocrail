/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jul 29 2015 10:10:26)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Jul 29 10:10:35 2015
  */

#include "rocs/public/event.h"


static const char* name = "OEvent";

typedef struct OEventData {

    /** Event name. */
  char* name;
    /** Event handle. */
  void* handle;
    /**  */
  Boolean posted;

} *iOEventData;

static iOEventData Data( void* p ) { return (iOEventData)((iOEvent)p)->base.data; }

