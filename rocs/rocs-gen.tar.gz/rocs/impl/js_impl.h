/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jun  6 2015 14:55:49)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Jun  7 08:59:25 2015
  */

#include "rocs/public/js.h"


static const char* name = "OJS";

typedef struct OJSData {

    /** file descriptors */
  int jsfd[4];
    /** Listeners list. */
  iOList listeners[4];
    /** HID reader */
  iOThread reader;
    /**  */
  Boolean run;
    /**  */
  int devcnt;

} *iOJSData;

static iOJSData Data( void* p ) { return (iOJSData)((iOJS)p)->base.data; }

