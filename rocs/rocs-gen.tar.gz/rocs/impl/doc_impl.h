/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Feb  4 2015 15:53:27)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Thu Feb  5 07:35:30 2015
  */

#include "rocs/public/doc.h"


static const char* name = "ODoc";

/*  */
#define startToken "<%s"
/*  */
#define endToken "</%s>"
/*  */
#define endInline "/>"
/*  */
#define remToken "<!--"
/*  */
#define remEndToken "-->"
/*  */
#define propToken "<?"
/*  */
#define propEndToken "?>"
/*  */
#define varToken "<!"
/*  */
#define varEndToken ">"
typedef struct ODocData {

    /** Document. */
  iONode doc;
    /** Root. */
  iONode root;
    /** Is UTF-8 encoded. */
  Boolean utf8;

} *iODocData;

static iODocData Data( void* p ) { return (iODocData)((iODoc)p)->base.data; }

