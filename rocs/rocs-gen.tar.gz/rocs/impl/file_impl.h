/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jun  6 2015 14:55:49)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Jun  7 08:59:25 2015
  */

#include "rocs/public/file.h"


static const char* name = "OFile";

typedef struct OFileData {

    /** File handle. */
  FILE* fh;
    /**  */
  int openflag;
    /**  */
  char* path;
    /**  */
  long size;
    /**  */
  long readed;
    /**  */
  long written;
    /**  */
  int rc;

} *iOFileData;

static iOFileData Data( void* p ) { return (iOFileData)((iOFile)p)->base.data; }

