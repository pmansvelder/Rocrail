/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Jul 29 2015 10:10:26)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Wed Jul 29 10:10:35 2015
  */

#include "rocs/public/strtok.h"


static const char* name = "OStrTok";

typedef struct OStrTokData {

    /** String value. */
  char* str;
    /** Separator. */
  char sep;
    /** Number of tokens in this string. */
  int countTokens;
    /** Pointer to next token. */
  char* nextToken;

} *iOStrTokData;

static iOStrTokData Data( void* p ) { return (iOStrTokData)((iOStrTok)p)->base.data; }

