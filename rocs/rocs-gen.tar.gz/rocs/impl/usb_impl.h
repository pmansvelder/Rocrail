/** ------------------------------------------------------------
  * A U T O   G E N E R A T E D
  * Generator: Rocs ogen (build Apr 19 2015 09:26:30)
  * Module: rocs
  * XML: $Source: /home/cvs/xspooler/rocs/rocs.xml,v $
  * XML: $Revision: 1.85 $
  * Date: Sun Apr 19 09:58:03 2015
  */

#include "rocs/public/usb.h"


static const char* name = "OUSB";

typedef struct OUSBData {

    /**  */
  void* husb;
    /**  */
  int interfaceNr;
    /**  */
  int input_ep;
    /**  */
  int output_ep;

} *iOUSBData;

static iOUSBData Data( void* p ) { return (iOUSBData)((iOUSB)p)->base.data; }

